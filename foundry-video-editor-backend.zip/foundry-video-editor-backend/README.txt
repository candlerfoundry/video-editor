Foundry Video Editor — Backend Setup
=====================================

SETUP (one time only):
1. Install Python 3.14 from python.org
   - Check "Add Python to PATH" during install

2. Double-click start_server.bat
   - It will install everything it needs automatically
   - A window will open saying "Starting server on http://localhost:5000"

3. Keep that window open and go back to the Foundry Video Editor in your browser
   - The page will connect automatically — no refresh needed

EVERY TIME YOU USE THE APP:
- Double-click start_server.bat before opening the app
- Keep the window open while you work
- Close it when you're done

QUESTIONS?
Contact Emily Savant or your team lead.
